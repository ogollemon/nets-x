<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <!-- source: http://tut.php-quake.net/-->
<html xml:lang="de" lang="de">
    <head>
        <title>DNA database</title>
	<link href="css/screen.css" rel="stylesheet" type="text/css" />
    </head>
	
    <body>
	<div id="Huelle">
	<div id="header">
	<h1 class="titleX"> DNA - Fingerprint - Resolution Inc.</h1>
	</div>
	<div id="navi">
	</div>
	<div id="content">
<?php
	$Username = $_POST['Username'];
	$Password = $_POST['Password'];

	$db = new mysqli('localhost', 'root', '', 'www');
	if (mysqli_connect_errno()) {
    	die ('No connection to database: '.mysqli_connect_error().'('.mysqli_connect_errno().')');
    }
    $sql = "SELECT * FROM users WHERE username = '$Username' AND password = '$Password'";
    
	$result = $db->query($sql);
	
	if (!$result) {
    	die ('DB error: '.$db->error);
	}
	$arr = mysqli_fetch_assoc($result);
	if ( $arr[ID] ){
		echo"<table class=\"txt\">";
		echo"<tr>";
			echo"<td><b>Name:</b></td>";
			echo"<td>$arr[username]</td>";
		echo"</tr>";
		echo"<tr>";
			echo"<td><b>Password:</b></td>";
			echo"<td>$arr[password]</td>";
		echo"</tr>";
		echo"<tr>";
			echo"<td style=\"vertical-align:top;\"><b>Fingerprint:</b></td>";
			echo"<td>GATAAATCTGGTCTTA<br />TTCACTATACTAGAAT<br />CAACGTTCCGTTCCCA<br />TGTGAATGTATTGGAG<br />GTGAATTTCTAGGACA</td>";
		echo"</tr>";
		echo"</table>";
		
	}
	else {
		echo "<p class=\"txt\">Not authenticated! Please try again!</p>";
	}
?>	
	</div>
	</div>
    </body>
</html>
