<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <!-- source: http://tut.php-quake.net/-->
<html xml:lang="de" lang="de">
    <head>
        <title>DNA database</title>
	<link href="css/screen.css" rel="stylesheet" type="text/css" />
    </head>
	
    <body>
	<div id="Huelle">
	<div id="header">
	<h1 class="titleX"> DNA - Fingerprint - Resolution Inc.</h1>
	</div>
	<div id="navi">
	</div>
	<div id="content">
        <form action="account.php" method="post" style="margin-top:140px;">
        	<table>
			<tr>
			<td><label for="name">Username:</label></td>
			<td><input type="text" name="Username" id="name"/></td>
			</tr>
			<tr>
			<td><label for="pass"> Password:</label></td>
			<td><input type="password" name="Password" id="pass"/></td>
			</tr>
			<tr>
			<td colspan="2"><input type="submit" name="formaction" value="Einloggen" /></td>
			</tr>
		</table>
		</form>
	</div>
	</div>
    </body>
</html>
