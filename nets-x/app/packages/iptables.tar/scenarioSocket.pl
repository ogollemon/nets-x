#!/usr/bin/perl -w

use IO::Socket;

my $sock = new IO::Socket::INET (
	LocalHost => '0.0.0.0',
	LocalPort => 'OPEN_PORT',
	Proto => 'tcp',
	Listen => 1,
	Reuse => 1,
);
die "Could not create socket: $!\n" unless $sock;
while ($client_addr = accept(CLIENT, $sock)){
	# find out who connected
	my ($client_port, $client_ip) = sockaddr_in($client_addr);
	my $client_ipnum = inet_ntoa($client_ip);
	# print who has connected
	# send them a message, close connection
	my $input = <CLIENT>;
	if ( substr($input,0,4) eq "quit"){
		print CLIENT "shutting down socket server.\n";
		close CLIENT;
		exit 0;
	} else {
		print CLIENT "Hello"; # indicate that the port is still open!
	}
	close CLIENT;
}
