#!/bin/bash

# Author Joao Collier de Mendonca
# Adapted from the script by Thomas Geimer
# Part of the Geimer/Mendonca Didactic CTF

SOURCEFILE="$1" # the source code to be compiled
EXECFILE="$2" # the output - compiled executable file

# test if the file c source file exists
[ ! -f "$SOURCEFILE" ] && exit 1

#echo -e "\nThis scripts compiles $SOURCEFILE"

# echo SOURCEFILE $SOURCEFILE; echo OUTPUTFILE $OUTPUTFILE; exit 123;
#echo "Compiling $SOURCEFILE"
COMPILECOMMAND="gcc -static -o $EXECFILE $SOURCEFILE -fno-stack-protector"
$COMPILECOMMAND
RV=$?
if [ $RV -ne 0 ]; then
    echo "Error on compile! RV=$RV"; 
    exit $RV;
# else
#     echo "Compiling done!"
fi



