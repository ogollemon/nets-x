/*
This program reads data from the billing file and calculates the respective tax for each client.

// NetS-X Project
// Author: Joao Collier de Mendonca
// This program is part of the gap-scenarios between NetS-X and the Didactic CTF of Geimer/Mendonca 2009.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CLIENTLENGTH 64
#define SUMLENGTH 7
#define VATPERCENT 19.0
#define LINEPATTERN "%[^,],%s\n"
#define OUTPUTPATTERN "%s,%s,%s\n"

int main(int argc, char **argv) {
        //char *myMsg;
        char msgHello[] = "Welcome to the billing program - NetS-X Corporation (c) 2009";
        char filepath[256];        
        // check filepath as argument
        if (argc != 2) {
                fprintf(stderr, "Usage: %s billingfile.csv\n", *argv);
                return(1);
        }
        strcpy(filepath, argv[1]);
        printf("\n\n%s\n\n", msgHello);
        readfile(filepath); // this reads the file and calculates the taxes
        //puts(filepath);
        //puts(msgHello);       
        puts("\nSession ended!\n");
        return(0);
}

int readfile( char *filepath ) {
        FILE *fp;
        char field1[CLIENTLENGTH];    // field1 is the clientID
        char field2[SUMLENGTH];         // field2 is the value
        float vat;
        float sum;
        char vatText[32];
        fp = fopen(filepath, "r");
        if(fp) {
                printf("Client, Total Sum, VAT (%0.2f\%)\n", (VATPERCENT) );
                while ( (fscanf(fp, LINEPATTERN, &field1, &field2)) != EOF )
                {
                    //sum = atof(field2);
                    //vat = sum * (VATPERCENT/100);
                    vat = atof(field2)* (VATPERCENT/100);
                    //printf("%s | %0.2f | %0.2f\n", field1, sum, vat);
                    sprintf(vatText, "%0.2f", vat);
                    printf("%s,%s,%s\n", field1, field2, vatText);
                    //printf(OUTPUTPATTERN, field1, sum, vat);
                }
                
        fclose(fp);
        return 0;
        }
        else { return(-1); }
        
        
}

