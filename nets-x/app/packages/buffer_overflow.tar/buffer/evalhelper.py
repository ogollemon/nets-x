#!/usr/bin/python

import re
import sys

# Return values definition
EVAL_FAILURE = 1
EVAL_SUCCESS_READY = 2
EVAL_NOTREADY = 3
ERRORMARGINPERCENT=2.0
VATPERCENT=19.0


def clientListOutput( outputFile=None, DEBUGMODE=False ):
    """
    This function reads the output from the billing.c program.
    It compares:
        - The first field of the output line with the first field of the billingdata.csv
        - If the third field is 19% of the second field
        The 19% comes from the constant #define VATPERCENT 19.0 
        hardcoded in the billing.c file.  If changed, its needs to be changed here as well.
    
    """
    if DEBUGMODE:
        print "clientListOutput"

    if not outputFile:
        print "Useroutputfile.txt not given. Exiting"
        sys.exit(EVAL_FAILURE)
        
    try:
        foutput = open(outputFile ,'r')
        userOutput = foutput.read()
        foutput.close()
    except IOError:
        print "IOError: Could not read file %s!" % (outputFile)
        sys.exit(EVAL_FAILURE)
    
    #validLinePattern  = "(([^,]+?)[,](([^,][0-9.])+?)[,](([^,][0-9.])+?))"
    validLinePattern  = "(([^,]+),(([0-9.])+),(([0-9.])+)$)"
    

    p = re.compile(validLinePattern)

    #goodline = 'Gommerzmann AG,1111111111111110000.57,211111111615840256.00' # should match
    #badline = 'Welcome to the billing program - NetS-X Corporation (c) 2009' # should NOT match
    #p.match(goodline)
    #p.match(badline)

    #resultLines = []
    clientListOutput=[] # this stores the client list, after the user program has processed the input file
    # outputList=[] # a list with client, sum, vat as elements
    dictOutput ={}

    for line in userOutput.split('\n'):
        #if DEBUGMODE: 
            #print line
        if p.match(line):
            if DEBUGMODE:
                print "matching for '%s'" % line
            
            try:
                client, clientSum, clientVAT = line.split(',')
                #client, clientSum, clientVAT = line
                clientListOutput.append( client )
                dictOutput[client]={'line':line, 'clientSum': clientSum, 'clientVAT':clientVAT}
                #outputList.append((client, csum, vat))
            except:
                print "ERROR: Invalid line in the output file: %s" % line # could not parse line
                sys.exit(EVAL_FAILURE)
        else:
            if DEBUGMODE:
                print "NO MATCH for '%s'" % line

    return dictOutput

def verifyVAT(clientSum, clientVAT, vat=VATPERCENT, error=ERRORMARGINPERCENT):
    
    """ This functions compares if vat is = VATPERCENT * csum +- ERRORMARGIN
        And returns a Boolean.    
    """

    fSum=float(clientSum)
    fVat=float(clientVAT)
    # vat >= (fSum*VATPERCENT)-(fSum*ERRORMARGIN) ~ fSum*(VATPERCENT-ERRORMARGIN)
    # vat <= (fSum*VATPERCENT)+(fSum*ERRORMARGIN) ~ fSum*(VATPERCENT+ERRORMARGIN)
      
    return ((fVat >= fSum*((VATPERCENT-ERRORMARGINPERCENT)/100)) and \
                (fVat <=fSum*((VATPERCENT+ERRORMARGINPERCENT)/100)))
    


def verifyLine(line):
    """ This functions compares if vat is = VATPERCENT * csum +- ERRORMARGIN
    """
    validLine=False
    client, clientSum, clientVAT = line.strip().split(',')
    if clientSum:
        if clientVAT:
            #try:
            if verifyVAT(clientSum, clientVAT):
                validLine=True
                if DEBUGMODE:
                    print "Line is valid: %s" % (line)
            else:
                validLine=False
                if DEBUGMODE:
                    print "ERROR: The calculated vat value is wrong in the following line of the output file: %s" % line
            #except:
        else:
            if DEBUGMODE:
                print "ERROR: Line is invalid (could not parse it, wrong format?): %s" % (line)
            validLine=False

    return validLine, client, clientSum, clientVAT

# now read the client list from the input file

def clientListfromDataFile( dataFile=None, DEBUGMODE=False ):
    if DEBUGMODE:
        print "clientListfromDataFile"

    if not dataFile:
        print "Datafile.csv not given. Exiting"
        sys.exit(EVAL_FAILURE)

    try:
        fdata = open(dataFile,'r')
        dataText = fdata.read()
        fdata.close()
    except IOError:
        print "IOError: Could not read file %s!" % (dataFile)
        sys.exit(EVAL_FAILURE)
    
    clientListData=[]
    DataPattern = "(([^,]+),((\s)*([0-9.])+))"
    dp = re.compile(DataPattern)
    for line in dataText.split('\n'):
        if dp.match(line):
            clientListData.append(line.split(',')[0])
            if DEBUGMODE:
                print "matching for '%s'" % line

    return clientListData

def verifyResults(clientListOriginal, outputDict, DEBUGMODE=False ):

    """ """
    valuesOK=True
    
    # verify if every client is present in the results:
    clientsinOutput = outputDict.keys()
    
    for client in clientListOriginal:
        if client not in clientsinOutput:
            # client was not in output results
            if DEBUGMODE:
                print "ERROR: the values for client %s were not present in the results" % client
            valuesOK = valuesOK and False
            break # abort the search, will return false
        else:
            # go further and check if the values are correct
            if outputDict.has_key(client):
                clientSum = outputDict[client]['clientSum']
                clientVAT = outputDict[client]['clientVAT']
                line = outputDict[client]['line']
                if not verifyVAT(clientSum, clientVAT):
                    if DEBUGMODE:
                        print "ERROR: the values for VAT calculation were not correct on line: %s" % line
                    valuesOK = valuesOK and False
                    #break
                else:
                    if DEBUGMODE:
                        print "VAT OK on line: %s" % line
    
    return valuesOK
        
        
    #for co in clientListOriginal:            
        ##cuok = ""
        #for cu in userClientList:
            ##if cu.strip() == co.strip():
            #if cu == co:
                #cuok = cu
                #break # found the client
            #else:
                #cuok = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        #if DEBUGMODE:        
            #print "%s\t\t\t| %s" % (co, cuok)
        
        ##print clientListOriginal==userClientList

    # check if every client is present
    
                          
def main():
    """     
        Evaluation helper for the NetS-X Buffer overflow scenario
        Usage: ./evalhelper.py datafile.txt userprogramoutput.txt
        Where userprogramoutput.txt is generated by :
        ./billing datafile.csv > userprogramoutput.txt

    """
    #print "main"
    args = sys.argv[1:]
    nArgs = len(args)
    if nArgs < 2: # must have 2 parameters
        print main.__doc__
        sys.exit(1)

    dataFile = args[0]
    outputFile = args[1]
    
    DEBUGMODE = False
    if nArgs == 3:
        DEBUGMODE = True
        #print DEBUGMODE       

    clientListOriginal= []
    userClientList = []

    # read the input file and prepare client list (1)
    clientListOriginal = clientListfromDataFile(dataFile, DEBUGMODE)

    # read the output file and compare with (1)
    # outputList = clientListOutput(outputFile, DEBUGMODE)
    outputDict = clientListOutput(outputFile, DEBUGMODE)

    # if clientListOriginal==userClientList:
    if verifyResults(clientListOriginal, outputDict, DEBUGMODE):
        # user program did not destroy anything
        # TODO: we must now check the percent part
        retVal = EVAL_SUCCESS_READY

    else:
        # the user did not finish its tasks yet!
        retVal = EVAL_NOTREADY

    sys.exit(retVal)


if __name__ == "__main__":
    main()
