#!/bin/bash

# Author Joao Collier de Mendonca
# Adapted from the script by Thomas Geimer
# Part of the Geimer/Mendonca Didactic CTF

SOURCEFILE="billing.c"
DATAFILE="billingdata.csv"

# test if the file c source file exists
[ ! -f "$SOURCEFILE" ] && echo "Error: file $SOURCEFILE does not exist or cannot read it!" && exit 1

# test if the billingdata exists
[ ! -f "$DATAFILE" ] && echo "Error: file $DATAFILE does not exist or cannot read it!" && exit 1

echo -e "\nThis scripts compiles $SOURCEFILE and runs it against the $DATAFILE file\n"
OUTPUTFILE=`echo $SOURCEFILE | cut -d "." -f 1`

# echo SOURCEFILE $SOURCEFILE; echo OUTPUTFILE $OUTPUTFILE; exit 123;
echo "Compiling $SOURCEFILE, writing output to $OUTPUTFILE:"
COMPILECOMMAND="gcc -static -o $OUTPUTFILE $SOURCEFILE -fno-stack-protector"
$COMPILECOMMAND

RV=$?
if [ $RV -ne 0 ]; then
	echo "Error on compile! RV=$RV"; exit $RV;
else
	echo "Compiling done!"
fi

echo "Now running the program $OUTPUTFILE against $DATAFILE"
RUNCOMMAND="./$OUTPUTFILE $DATAFILE"
#$RUNCOMMAND || RV=$?; echo "Error while running! RV=$RV"; exit $RV;
$RUNCOMMAND
RV=$?
if [ $RV -ne 0 ]; then
    echo "Error while running! RV=$RV"; exit $RV;
fi


